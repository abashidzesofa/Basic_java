//1 Пользователь вводит число. Если число больше 0, то выполнить следующие операции:
// умножить число на 2, если оно нечётное;
// прибавить к числу 5, если если оно заканчивается на 5 или 0.
// Если число < 0, то взять его по модулю и разделить на 3.
//Результат вычисления вывести в консоль.

import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner scn = new Scanner(System.in);
        Random rnd = new Random();

        System.out.println("Задание 1:");
        System.out.println("Введите любое число:");
        int a = scn.nextInt();
        if (a > 0 && a%2==1){
            System.out.println(a*2);
        }
        if (a%10==5 ||a%10==0){
            System.out.println(a+5);
        }
        if (a<0){
            System.out.println(a%3);
        }






    }
}