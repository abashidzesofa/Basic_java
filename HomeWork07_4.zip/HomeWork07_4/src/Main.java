//4 С помощью Random сгенерируйте три числа.
// Напишите программу, которая находит максимальное из них.
// Используйте тернарные операторы.
import java.util.Random;
public class Main {
    public static void main(String[] args) {
        Random rnd = new Random();
        System.out.println("Задание 4:");
        int i1 = rnd.nextInt(1, 100);
        System.out.println("Сгенерируй первое число: " + i1);
        int i2 = rnd.nextInt(1, 100);
        System.out.println("Сгенерируй второе число: " + i2);
        int i3 = rnd.nextInt(1,100);
        System.out.println("Сгенерируй третье число: " + i3);
        if (i1 >i2 && i1>i3 ) {
            System.out.println(i1);
        }
        if (i2 >i1 && i2>i3 ) {
            System.out.println(i2);
        }
        if (i3 >i2 && i3>i1 ) {
            System.out.println(i3);
        }
    }
}