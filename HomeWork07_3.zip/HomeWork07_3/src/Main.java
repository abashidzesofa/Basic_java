//3 Пользователь вводит два числа.
// Если они не равны, то вывести в консоль их сумму, иначе вывести их произведение.
// Используйте тернарный оператор.
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        System.out.println("Задание 3:");
        System.out.println("Введите первое число :");
        int a = scn.nextInt();
        System.out.println("Введите второе число :");
        int b = scn.nextInt();
        System.out.println(a!=b? a+b : a*b);
    }
}